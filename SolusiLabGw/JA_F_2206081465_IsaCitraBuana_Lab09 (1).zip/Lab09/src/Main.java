import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.HashMap;
// Import kelas-kelas yang dibutuhkan


public class Main {
    public static void main(String[] args) {
        MainFrame.getInstance();
    } // Jalankan GUI

    /*
    * static mehod untuk mempermudah membuat spesifikasi
    * GridBagConstraints yang sesuai untuk melakukan penataan objek-objek pada GridBagLayout*/
    public static GridBagConstraints createConstraint(int x, int y, int anchor, int fill, int weightX, int weightY, int ipadX, int ipadY
            ,Insets insets){
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.weightx = weightX;
        gbc.weighty = weightY;
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.ipadx = ipadX;
        gbc.ipady = ipadY;
        gbc.anchor = anchor;
        gbc.fill = fill;
        gbc.insets = insets;
        return gbc;
    }
}

/*
* Kelas singleton untuk menyimpan data-data
*  atau informasi yang diperlukan oleh GUI*/
class DataBase{
    private double currentMoney; // field untuk current money yang dimiliki user
    private HashMap<String, Integer> mapProduk; // untuk simpan daftar barang yang dijual beserta harganya
    private static DataBase dataBase = new DataBase(); // singleton object

    private DataBase(){
        mapProduk = new HashMap<>();
        mapProduk.put("Akua", 5000);
        mapProduk.put("Fruti Apel", 8000);
        mapProduk.put("Palpi Jeruk", 7500);
        mapProduk.put("Neskafe Latte", 11000);
        mapProduk.put("Koka Kola", 9500);
    }

    public int getHargaProduk(String name){ // dapatkan harga produk sesuai nama produk
        return mapProduk.getOrDefault(name,-1);
    }


    // Setter currentMoney
    public void setCurrentMoney(double currentMoney) {
        this.currentMoney = currentMoney;
    }

    //Getter currentMoney
    public double getCurrentMoney() {
        return currentMoney;
    }

    //Getter instance
    public static DataBase getInstance(){
        return dataBase;
    }
}

// singleton window utama GUI
class MainFrame extends JFrame {
    private HomePage homePage; //Panel HomePage
    private MoneyInputPanel moneyInputPanel; // window untuk input uang
    private PurchaseProductPanel purchaseProductPanel; // window untuk purchase barang

    private DataBase dataBase; // data base

    private  static MainFrame mainFrame = new MainFrame(DataBase.getInstance()); // singleton object

    // getter instance
    public static MainFrame getInstance(){
        return mainFrame;
    }

    // buat window untuk purchase product
    void goToPurchaseProduct(){
        this.purchaseProductPanel = new PurchaseProductPanel();

    }
    // getter dataBase
    public DataBase getDataBase(){
        return this.dataBase;
    }

    //Siapkan MainFrame dan kontennya
    MainFrame(DataBase dataBase){
        setLocationRelativeTo(null);
        this.homePage = HomePage.getInstance();
        this.dataBase = dataBase;
        this.setContentPane(homePage);
        invalidate();
        validate();
        setSizeMainFrame();
        this.setTitle("Vending Machine");
        this.setVisible(true);
    }
    // Buat window untuk menambahkan uang
    void createMoneyInputWindow(){
        this.moneyInputPanel = new MoneyInputPanel();
    }


    // Fungsi prosedural untuk mengatur size dan preferred size dari frame
    void setSizeMainFrame(){
        this.setSize(new Dimension(500,400));
        this.setPreferredSize(new Dimension(500, 400));
    }
}

// kelas untuk window menambahkan uang
class MoneyInputPanel extends JFrame{
    private JLabel label; // label "Money Input"
    private JTextField textField; // textfield uang yang akan ditambahkan
    private JButton submit; // button untuk menambahkan uang

    MoneyInputPanel(){
        this.setLayout(new GridBagLayout());
        setLocationRelativeTo(null);
        this.setTitle("Money Input");
        this.setSize(new Dimension(500,400));
        this.setPreferredSize(new Dimension(500,400));
        this.label = new JLabel("Enter the amount of money:");
        this.textField = new JTextField(20);
        this.submit = new JButton("Submit");

        // tambahkan ActionListener
        this.submit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /*Dapatkan  value uang yang dimiliki sebelumnya,
                * kemudian update uang sekarang = uang sebelum + tambahan uang.
                * Selanjutnya munculkan event Property Change sehingga nanti akan ditangkap
                * oleh Property Change Listener yang akan mengupdate tampilan GUI.
                * Lalu keluar dari window tambahkan uang ini*/

                double prev = MainFrame.getInstance().getDataBase().getCurrentMoney();
                MainFrame.getInstance().getDataBase().setCurrentMoney
                        (Integer.parseInt(textField.getText())+MainFrame.getInstance().getDataBase().getCurrentMoney());
                submit.firePropertyChange("updateoi", prev,
                        MainFrame.getInstance().getDataBase().getCurrentMoney());
                dispose();
            }
        });

        submit.addPropertyChangeListener(HomePage.getInstance()); // Tambahkan PropertyChangeListener


        // Design

        GridBagConstraints constraints = new GridBagConstraints(0,1,0,0,
                0,0,GridBagConstraints.NORTH,
                GridBagConstraints.HORIZONTAL,new Insets(30,0,30,0), 0,0);
        this.add(textField, constraints);
        constraints = new GridBagConstraints(0,2,0,0,0,
                0,GridBagConstraints.WEST,GridBagConstraints.HORIZONTAL,
                new Insets(60,0,30,0),0,0);
        this.add(submit, constraints);
        constraints = new GridBagConstraints(0,0,0,0,
                0,0,GridBagConstraints.NORTH,
                GridBagConstraints.HORIZONTAL,new Insets(0,0,50,0), 0,0);
        this.add(label, constraints);
        this.setVisible(true);
    }
}


class PurchaseProductPanel extends JFrame{
    private JPanel productPanel;
    private JComboBox<String> comboBox;
    private JTextField quantityTextField, priceTextField, totalPriceTextField;
    private PropertyChangeSupport changeSupportPrice;
    private JButton purchaseButton;

    private  JOptionPane popUpJumlahTidakValid, popUpKembalian ;
    PurchaseProductPanel(){

        // Design

        this.setTitle("Purchase Product");
        setLocationRelativeTo(null);
        this.setSize(new Dimension(500,400));
        this.setPreferredSize(new Dimension(500,400));
        changeSupportPrice = new PropertyChangeSupport(this);
        this.setLayout(new GridLayout(5,1));
        createProductPanel();
        this.quantityTextField = createOtherPanel("Quantity", 20);
        this.priceTextField = createOtherPanel("Price",29);
        this.totalPriceTextField = createOtherPanel("Total Price",9);
        this.priceTextField.setEditable(false);
        this.totalPriceTextField.setEditable(false);
        this.popUpKembalian = new JOptionPane();
        purchaseButton = createOtherPanel("Purchase");

        // tambah ActionListener ke comboBox
        this.comboBox.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /* selected objectnya telah diganti maka harus fire (mengeluarkan)
                * event Property Change untuk ditangkap
                *  objek yang membutuhkan perubahan tampilan
                */
                changeSupportPrice.firePropertyChange("changeComboBoxSelectedItem", 0,1);
            }
        });

        /* tambah DocumentListener ke quantityTextField untuk
        * mengaktifkan reaksi  yang perlu dimunculkan
        * ketika textfield ini diubah. Reaksi tersebut berupa munculnya
        * event Property Change yang akan ditangkap objek-objek yang membutuhkan perubahan tampilan
        * */
        this.quantityTextField.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) {
                changeSupportPrice.firePropertyChange("changeQuantityItem", 0, 1);
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                changeSupportPrice.firePropertyChange("changeQuantityItem", 0, 1);
            }

            @Override
            public void changedUpdate(DocumentEvent e) {
                changeSupportPrice.firePropertyChange("changeQuantityItem", 0, 1);
            }
        });


        /*
        * tambah change property listener untuk menghasilkan reaksi atas
        * event Change Property yang dimunculkan oleh changSupportPrice*/
        changeSupportPrice.addPropertyChangeListener(new PropertyChangeListener() {
            @Override
            public void propertyChange(PropertyChangeEvent evt) {

                /*
                * Reaksi ubah priceTextField dan totalPriceTextField secara otomatis
                * mengikuti barang yang mau dibeli dan jumlahnya
                * */
                if(evt.getPropertyName().equals("changeComboBoxSelectedItem")
                        || evt.getPropertyName().equals("changeQuantityItem")){
                    try {
                        String choice = (String) comboBox.getSelectedItem();
                        Double getPrice = Double.valueOf(DataBase.getInstance().getHargaProduk(choice));
                        priceTextField.setText(String.format("Rp.%.1f", getPrice));
                        totalPriceTextField.setText(String.format("Rp.%.1f", getPrice * Double.parseDouble(quantityTextField.getText())));
                    } catch (Exception e){
                        String choice = (String) comboBox.getSelectedItem();
                        Double getPrice = Double.valueOf(DataBase.getInstance().getHargaProduk(choice));
                        priceTextField.setText(String.format("Rp.%.1f", getPrice));
                        totalPriceTextField.setText("");
                    }

                }
            }
        });
        changeSupportPrice.firePropertyChange("changeComboBoxSelectedItem", 0,1);

        purchaseButton.addPropertyChangeListener(HomePage.getInstance()); // Connect perubahan ke window utama

        // Tambahkan ActionListener ke purchaseButton untuk menghasilkan reaksi ketika ditekan
        purchaseButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String choice = (String) comboBox.getSelectedItem();
                Double getPrice = Double.valueOf(DataBase.getInstance().getHargaProduk(choice));
                DataBase dataBaseInstance = DataBase.getInstance();

                // reaksi jika jumlah barang tidak valid
                if(Double.parseDouble(quantityTextField.getText()) <= 0){

                    // tampilkan pop up
                    JOptionPane.showMessageDialog(popUpKembalian,
                            "Maaf, jumlah barang yang Anda masukkan tidak valid!","Info",JOptionPane.ERROR_MESSAGE);

                    return;
                }

                // reaksi jika jumlah barang kurang
                if(dataBaseInstance.getCurrentMoney() - getPrice * Double.parseDouble(quantityTextField.getText()) < 0){
                    JOptionPane.showMessageDialog(popUpKembalian, "Maaf, uang Anda tidak cukup!",
                            "Info", JOptionPane.ERROR_MESSAGE); // tampilkan pop up
                    return;
                }
                // reaksi jika sesuai
                dataBaseInstance.setCurrentMoney(dataBaseInstance.getCurrentMoney()- getPrice * Double.parseDouble(quantityTextField.getText()));
                purchaseButton.firePropertyChange("updateoi", 0, 1);
                // buat event Property Change untuk mentrigger perubahan GUI

                JOptionPane.showMessageDialog(popUpKembalian,  String.format("Berhasil! Kembalian Anda sebesar %.1f",
                        dataBaseInstance.getCurrentMoney()), "Info", JOptionPane.INFORMATION_MESSAGE);
                // tampilkan pop up

                quantityTextField.setText("");
                totalPriceTextField.setText("");


            }
        });
        this.setVisible(true);
    }

    // method untuk design label "Product: " dan ComBoBox
    void createProductPanel(){
        productPanel = new JPanel(new GridBagLayout());
        JLabel productLabel = new JLabel("Product: ");
        GridBagConstraints gridBagConstraints = new GridBagConstraints(0,0,
                1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0,0,0,20),0,0);
        productPanel.add(productLabel, gridBagConstraints);
        comboBox = new JComboBox<>(new String[]{"Akua", "Fruti Apel", "Palpi Jeruk", "Neskafe Latte", "Koka Kola"});
        gridBagConstraints =  new GridBagConstraints(1,0,
                1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0,0,0,0),0,0);
        productPanel.add(comboBox, gridBagConstraints);
        comboBox.setSelectedIndex(0);
        this.add(productPanel);
    }

    // method untuk membuat label beserta textfieldnya. Return JTextfield agar bisa disimpan di variable untuk diakses
    JTextField createOtherPanel(String judul, int hGap){
        JPanel panel = new JPanel(new GridBagLayout());
        JLabel quantityLabel = new JLabel(judul+": ");
        GridBagConstraints gridBagConstraints = new GridBagConstraints(0,0,
                1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0,0,0,hGap),0,0);
        panel.add(quantityLabel, gridBagConstraints);
        gridBagConstraints = new GridBagConstraints(1,0,
                1, 1, 0, 0, GridBagConstraints.WEST, GridBagConstraints.NONE,
                new Insets(0,0,0,0),0,0);
        JTextField textField = new JTextField(10);
        panel.add(textField, gridBagConstraints);
        this.add(panel);
        return  textField;
    }

    // overload untuk membuat button. Return JButton agar bisa disimpan ke variable untuk diakses
    JButton createOtherPanel(String judul){
        JPanel jPanel = new JPanel(new GridBagLayout());
        JButton button = new JButton(judul);
        jPanel.add(button);
        this.add(jPanel);
        return button;
    }

}

/*
* singleton yang berguna untuk membuat konten bagi window utama.
* Selain itu, juga agar adaptif terhadap perubahan*/
class  HomePage extends  JPanel implements PropertyChangeListener  {
    private JLabel label;
    private JButton addMoneyButton, purchaseProductButton;

    private static HomePage homePage = new HomePage();

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        if(evt.getPropertyName().equals("updateoi")){
            this.label.setText("Total Money: Rp."+String.format("%.1f",DataBase.getInstance().getCurrentMoney()));
        }
    }
    // Getter instance
    public static HomePage getInstance(){
        return homePage;
    }

    // sngleton pattern
    private HomePage(){
        this.setLayout(new GridBagLayout());
        this.label = new JLabel("Please select an option");
        this.addMoneyButton = new JButton("Add Money");
        this.purchaseProductButton = new JButton("Purchase Product");

        // Agar membuka window  untuk menambahkan uang
        this.addMoneyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MainFrame.getInstance().createMoneyInputWindow();
            }
        });

        // Agar membuka window untuk purchase barang
        this.purchaseProductButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MainFrame.getInstance().goToPurchaseProduct();
            }
        });


        //Design

        GridBagConstraints constraints = Main.createConstraint(0,0,GridBagConstraints.CENTER,
                GridBagConstraints.BOTH, 0, 0, 0, 0,
                new Insets(0,100,0,0)
        );
        constraints.gridwidth = 2;
        this.add(this.label, constraints);
        this.add(this.addMoneyButton, Main.createConstraint(0,1,GridBagConstraints.CENTER,
                GridBagConstraints.BOTH, 0, 0, 50, 0,
                new Insets(30,0,0,30)));
        this.add(this.purchaseProductButton, Main.createConstraint(1,1,GridBagConstraints.CENTER,
                GridBagConstraints.BOTH, 0, 0, 0, 0,
                new Insets(30,0,0,30)));
        this.setVisible(true);
    }
}