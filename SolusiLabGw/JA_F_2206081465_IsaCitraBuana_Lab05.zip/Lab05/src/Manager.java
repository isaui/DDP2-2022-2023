
public class Manager extends Employee {

    // Field
    private static final double RAISE = 1.25; // Kenaikan tetap
    private static final double BASE_GAJI = 2000000; // Gaji awal tetap
  
    Manager (String nama){
      // TODO lengkapi constructor ini
        super(nama);
    }
    
    // Method untuk merepresentasikan informasi objek Manager dalam bentuk String
    @Override
    public String toString() {
        String deskripsi = """
                Nama: %s
                Pengalaman Kerja: %d
                Status: %s
                NetWorth: Rp%.2f
                Jabatan: %s
                Role: Manager
                """;
        return String.format(deskripsi, getNama(), getPengalamanKerja(),
                String.valueOf(isStatus()), getNetWorth(), getJabatan());
    }


    // Increment pengalaman kerja tahun demi tahun sembari mengatur ulang jabatan dan
    // pendapatan objek Manager ini. Break pertama menolak
    // meningkatkan pengalaman kerja jika objek itu sudah pensiun. Break kedua
    // menolak meng-update pendapatan jika objek itu sudah pensiun.
    @Override
    public void nextYear(int n){
        for(int i = 0; i < n ; i++){
            if(isStatus() == false) break;
            setPengalamanKerja(getPengalamanKerja()+1);
            pembagianJabatanTetap(getPengalamanKerja());
            if(isStatus() == false) break;
            setNetWorth(getNetWorth() + getGaji());
        }
    }
  
    // Jika ini tahun pertamanya bekerja maka atur gaji objek Manager ini
    // menjadi sebesar gaji dasarnya (#BASE_GAJI) dikalikan kenaikan (#RAISE).
    // Lain dari itu, atur jabatan, status, dan gaji objek Manager tersebut.
    // Untuk gajinya diatur sebesar gaji sebelumnya dikalikan kenaikan (#RAISE).
    public void pembagianJabatanTetap (int tahunBekerja){
        if (tahunBekerja == 1) {
            setGaji(BASE_GAJI * RAISE);
            return;
        }
        String jabatan = tahunBekerja <= 5 ? "Junior" :
                tahunBekerja <= 10 ? "Senior" : tahunBekerja <= 15 ? "Expert" : "Pensiun";
        setJabatan(jabatan);
        boolean apakahAktifBekerja = ! getJabatan().equals("Pensiun")? true : false;
        setStatus(apakahAktifBekerja);
        setGaji(getGaji() * RAISE);
    }
  
  }