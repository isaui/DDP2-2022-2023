public abstract class Employee{
    // Kelas #Employee adalah kelas abstrak karena digunakan
    // sebagai kerangka untuk subclass-nya. Dengan demikian kelas #Employee ini
    // tidak perlu diinstantiate.

    // Field
    private String nama;
    private int pengalamanKerja;
    private boolean status;
    private double netWorth;
    private String jabatan;
    private double gaji;
  
    Employee(String nama){
        this.nama = nama;
        setStatus(true); // Statusnya aktif bekerja
        setJabatan("Junior"); // Semua jabatan pasti dimulai dari Junior
    }

    // Method Abstrak untuk diimplementasi oleh child classnya
    public  abstract void nextYear(int tahun);

    // getter #status
    public boolean isStatus() {
        return status;
    }

    // setter #status
    public String getNama() {
        return nama;
    }

    //getter #jabatan
    public String getJabatan() {
        return jabatan;
    }

    // setter #pengalamanKerja
    public void setPengalamanKerja(int pengalamanKerja) {
        this.pengalamanKerja = pengalamanKerja;
    }

    // setter #status
    public void setStatus(boolean status) {
        this.status = status;
    }

    // setter #jabatan
    public void setJabatan(String jabatan){

        this.jabatan = jabatan;
    }

    // getter #pengalamanKerja
    public int getPengalamanKerja(){

        return pengalamanKerja;
    }

    // getter #netWorth
    public double getNetWorth(){

        return netWorth;
    }

    // setter #netWorth
    public void setNetWorth(double n){

        netWorth = n;
    }

    // setter #gaji
    public void setGaji(double gaji) {

        this.gaji = gaji;
    }

    // getter #gaji
    public double getGaji() {

        return gaji;
    }
}