// import kelas yang dibutuhkan
import java.util.ArrayList;
import java.util.Scanner;

public class PacilWorks {

    // Field
    private static ArrayList<Employee> employees = new ArrayList<>();
    // Struktur data untuk menyimpan objek turunan #Employee
    private static Scanner in = new Scanner(System.in);
    // Objek dari kelas #Scanner untuk membaca input

    // Static Method untuk menampilkan "=====..."
    private static void printSeparator() {

        System.out.println("=".repeat(64));
    }

    // tranverse ArrayList #employees
    private static void daftarEmployee() {
        if(employees.size() == 0){
            System.out.println("PacilWorks tidak memiliki karyawan :(");  
            printSeparator();
            return;
        }
        printSeparator();
        System.out.printf("PacilWorks memiliki %d total karyawan:\n", employees.size());
        for(Employee e : employees) {
            System.out.println("- " + e);
        }
        printSeparator();
    }

    // tranverse ArrayList #employees dan panggil
    // instance method #nextYear dari setiap objek
    // turunan #Employee yang tersimpan di ArrayList tersebut
    private static void nextYear(int n) {
        for(Employee e : employees) {
            e.nextYear(n);
        }
    }

    // Tambahkan objek turunan #Employee ke ArrayList #employees
    private static void handleAddEmployee(){
        System.out.print("Masukkan role employee: ");
        String role = in.nextLine();
        String nama;
                
        if(role.equalsIgnoreCase("Engineer")) {
            // TODO tambahkan engineer ke array employees
            System.out.print("Nama: ");
            nama = in.nextLine();
            String banyakSideJobs;
            System.out.print("Banyak Side Jobs: ");
            while (true){ // validasi Side Jobs objek Engineer
                banyakSideJobs = in.nextLine();
                if(banyakSideJobs.chars().allMatch(Character::isDigit) ){
                    if(Integer.parseInt(banyakSideJobs) >= 0) break; // valid
                }
                System.out.println("Jumlah Side Jobs harus bilangan bulat >= 0");
            }
            employees.add(new Engineer(nama, Integer.parseInt(banyakSideJobs)));

        } else if(role.equalsIgnoreCase("Secretary")) {
            System.out.print("Nama: ");
            nama = in.nextLine();
            System.out.print("Banyak tunjangan: ");
            double banyakTunjangan;
            while (true){ // validasi tunjangan objek Secretary
                try {
                    banyakTunjangan = Double.parseDouble(in.nextLine());
                    if(banyakTunjangan >= 0) break; // valid
                    System.out.println("Jumlah tunjangan harus bilangan >= 0");
                } catch (Exception exception){
                System.out.println("Jumlah tunjangan harus bilangan >= 0");
                }
            }
            employees.add(new Secretary(nama, banyakTunjangan));
            // TODO tambahkan secretary ke array employees

        } else if(role.equalsIgnoreCase("Manager")) {
            System.out.print("Nama: ");
            nama = in.nextLine();
            employees.add(new Manager(nama));

            // TODO tambahkan manager ke array employees
            
        } else {
            System.out.println("Masukkan tidak sesuai. Silahkan coba lagi!");
        }
    }

    // root eksekusi program
    public static void main(String[] args) {
        System.out.print("Selamat datang di PacilWorks!");
        System.out.print("\n");

        while(true) {
            System.out.printf("" +
            "Silakan pilih salah satu opsi berikut:\n" +
            "[1] Daftar Karyawan\n" +
            "[2] Tambah Karyawan\n" +
            "[3] Simulasi n-tahun berikutnya\n" +
            "[*] Keluar\n");
            printSeparator();

            System.out.print("Input: ");
            String pilihan = in.nextLine();
            
            if(pilihan.equals("1")) {
                daftarEmployee();
            } else if(pilihan.equals("2")) {
                handleAddEmployee();
            } else if(pilihan.equals("3")) {
                System.out.print("Masukkan banyak tahun yang ingin disimulasikan: ");
                int banyakTahun = Integer.parseInt(in.nextLine());
                nextYear(banyakTahun);
                System.out.printf("%d tahun telah berlalu...\n", banyakTahun);
                printSeparator();
            } else {
                System.out.println("Terima kasih telah menggunakan layanan PacilWorks ~ !");
                break;
            }
        }
        
        in.close();
    }
}