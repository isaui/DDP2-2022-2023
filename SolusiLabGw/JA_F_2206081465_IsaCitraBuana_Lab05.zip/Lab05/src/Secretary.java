// TODO Class Secretary adalah subclass dari Employee
public class Secretary  extends Employee{
    // Field
    private double tunjangan;
  
    Secretary (String nama, double tunjangan){
        super(nama);
        this.tunjangan = tunjangan;
    }
    
    // Method untuk merepresentasikan informasi objek Secretary dalam bentuk String
    @Override
    public String toString() {
        String deskripsi = """
                Nama: %s
                Pengalaman Kerja: %d
                Status: %s
                NetWorth: Rp%.2f
                Jabatan: %s
                Role: Secretary
                Banyak Tunjangan: %.2f
                """;
        return String.format(deskripsi, getNama(), getPengalamanKerja(),
                String.valueOf(isStatus()), getNetWorth(), getJabatan(), this.tunjangan) ;
    }

    // Increment pengalaman kerja tahun demi tahun sembari mengatur ulang jabatan,
    // gaji, dan pendapatan objek Secretary ini. Break pertama menolak
    // meningkatkan pengalaman kerja jika objek itu sudah pensiun. Break kedua
    // menolak meng-update pendapatan jika objek itu sudah pensiun.
    @Override
    public void nextYear(int n){
        for(int i = 0; i < n ; i++){
            if(isStatus() == false) break;
            setPengalamanKerja(getPengalamanKerja()+1);
            pembagianGajiDanJabatanTetap(getPengalamanKerja());
            if(isStatus() == false) break;
            setNetWorth(getNetWorth() + getGaji() + this.tunjangan);
        }
    }
    
    // Update jabatan, gaji, dan status objek Secretary ini
    public void pembagianGajiDanJabatanTetap(int tahunBekerja){
        String jabatan = tahunBekerja <= 5 ? "Junior" :
                tahunBekerja <= 10 ? "Senior" : tahunBekerja <= 15 ? "Expert" : "Pensiun";
        setJabatan(jabatan);
        double gajiUpdate = getJabatan().equals("Junior") ? 3000000 : getJabatan().equals("Senior") ? 6000000 :
                getJabatan().equals("Expert") ? 9000000 : 0;
        setGaji(gajiUpdate);
        boolean apakahAktifBekerja = ! getJabatan().equals("Pensiun")? true : false;
        setStatus(apakahAktifBekerja);
    }
  
  }