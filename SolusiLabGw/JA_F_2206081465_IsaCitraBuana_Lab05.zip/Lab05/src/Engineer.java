
public class Engineer extends  Employee{

    // Field
    private int banyakSideJobs;
    Engineer (String nama, int banyakSideJobs){
        super(nama);
        this.banyakSideJobs = banyakSideJobs;
    }
  
    // Method untuk merepresentasikan informasi objek Engineer dalam bentuk String
    @Override
    public String toString() {
        String deskripsi ="""
                Nama: %s
                Pengalaman Kerja: %d
                Status: %s
                NetWorth: Rp%.2f
                Jabatan: %s
                Role: Engineer
                Banyak SideJobs: %d
                """;
        return String.format(deskripsi, getNama(),
                getPengalamanKerja(), String.valueOf(isStatus()),
                getNetWorth(), getJabatan(), getBanyakSideJobs());
    }

    // getter #banyakSideJobs
    public int getBanyakSideJobs() {
        return banyakSideJobs;
    }

    // Increment pengalaman kerja tahun demi tahun sembari mengatur ulang jabatan,
    // gaji, dan pendapatan objek Engineer ini. Break pertama menolak
    // meningkatkan pengalaman kerja jika objek itu sudah pensiun. Break kedua
    // menolak meng-update pendapatan jika objek itu sudah pensiun.
    @Override
    public void nextYear(int n){
      // TODO implementasikan method nextYear yang merupakan method override dari class Employee
        for(int i = 0; i < n; i++) {
            if (isStatus() == false) break;
            setPengalamanKerja(getPengalamanKerja() + 1);
            pembagianGajiDanJabatanTetap(getPengalamanKerja());
            if (isStatus() == false) break;
            setNetWorth(getNetWorth() + getGaji() + getBanyakSideJobs() * 500000);


        }
    }

    // Update jabatan, gaji, dan status
    public void pembagianGajiDanJabatanTetap(int tahunBekerja){
      // TODO implementasikan method pembagianGajiDanJabatanTetap
        String jabatan = tahunBekerja <= 5 ? "Junior" :
                tahunBekerja <= 10 ? "Senior" : tahunBekerja <= 15 ? "Expert" : "Pensiun";
        setJabatan(jabatan);
        double gajiUpdate = getJabatan().equals("Junior") ? 4000000 : getJabatan().equals("Senior") ? 8000000 :
                getJabatan().equals("Expert") ? 12000000 : 0;
        setGaji(gajiUpdate);
        boolean apakahAktifBekerja = ! getJabatan().equals("Pensiun")? true : false;
        setStatus(apakahAktifBekerja);
    }
  }