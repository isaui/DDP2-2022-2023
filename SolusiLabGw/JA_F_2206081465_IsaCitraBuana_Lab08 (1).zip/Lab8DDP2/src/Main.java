/*
* Nama: Isa Citra Buanq
* NPM: 2206081465
* Lab 08 DDP2
* */




import java.io.*; //Import semua kelas yang ada di package java io
import java.util.ArrayList; // Import kelas ArrayList
import java.util.Scanner; // Import kelas Scanner

public class Main {

    private static ArrayList<String> daftarMetaData = new ArrayList<>();
    /* Struktur data untuk menyimpan daftar meta data
    sementara yang berasal dari hasil pembacaan file txt*/

    public static void main(String[] args){
        File filePlayListPertama, filePlayListKedua;
        /*
        * Declare dua variable bertipe File untuk
        * File pertama dan kedua
        * */

        PrintWriter printWriter; // untuk menulis kembali ke merged.txt

        try{
            Scanner scan = new Scanner(System.in); // Membuat scanner untuk menerima masukan dari user
            String pathPlayListPertama, pathPlayListKedua;
            // declare dua variable bertipe String untuk menyimpan path
            // file playlist pertama dan path file playlist kedua

            System.out.print("File playlist pertama: ");
            pathPlayListPertama = scan.nextLine(); // path file playlist pertama
            filePlayListPertama = createExistingFile(pathPlayListPertama);
            validatePlayListAndAddIt(filePlayListPertama);
            System.out.print("File playlist kedua: ");
            pathPlayListKedua = scan.nextLine(); // path file playlist kedua
            filePlayListKedua = createExistingFile(pathPlayListKedua);
            validatePlayListAndAddIt(filePlayListKedua);

            scan.close();
            daftarMetaData = new ArrayList<>(daftarMetaData.stream().distinct().toList());
            // hilangkan metadata yang duplikat

            printWriter = new PrintWriter(new File("merged.txt"));
            // objek PrintWriter untuk menulis ke file merged.txt

            for(String metaData : daftarMetaData){
                printWriter.write(metaData+"\n"); // tulis metadata unik ke file merged.txt
            }
            System.out.println("File playlist output: merged.txt");
            System.out.println(String.format("Berhasil menimpa playlist, jumlah lagu adalah: %d",daftarMetaData.size()));
            daftarMetaData.clear();
            printWriter.close();

        } catch (FileNotFoundException fileNotFoundException){
            // catch Exception FileNotFoundexception

            System.out.println("File tidak ditemukan!");

        } catch (InvalidPlayListException invalidPlayListException){
            // catch Exception InvalidPlayListException

            System.out.println(invalidPlayListException);
        }
    }

    /*
    * Static Method untuk return objek File apabila String
    * pathName yang dimasukkan exist, jika tidak maka trigger atau
    * throw FileNotFoundException
    * */
    public static File createExistingFile(String pathName) throws FileNotFoundException{
        File file = new File(pathName);
        if(! file.exists()){
            throw new FileNotFoundException();
        }
        return file;
    }

    /*
    * Static method untuk membaca seluruh line di
    * file yang dituju dan menyimpannya ke arrayList daftarMetaData.
    *  Apabila tidak sesuai dengan aturan metadata
    * maka trigger exception InvalidPlayListException.
    * */
    public static void validatePlayListAndAddIt(File file) throws FileNotFoundException, InvalidPlayListException{
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()){
            daftarMetaData.add(isPlayListValid(scanner.nextLine()));
        }
        scanner.close();
    }

    /*
    * Static method untuk menentukan apakah input metadata valid atau tidak.
    * Valid atau tidaknya bisa dilihat dari beberapoa kriteria.
    * Kriteria pertama yaitu hasil split metaData
    * berdasarkan regex "//" harus menghasilkan array dengan panjang 2.
    * Kriteria kedua adalah melihat kemungkinan adanya backslash "/" pada metadata.
    * Backslash yang valid berada di tengah tengah metadata bukan diujung metadata,
    * baik metadata artis ataupun metadata nama lagu.
    * */
    public static String isPlayListValid(String metaData) throws InvalidPlayListException{

        String[] metaDataArray = metaData.split("\\|\\|");
        if(metaDataArray.length != 2){
            throw new InvalidPlayListException();
        }
        String artist = metaDataArray[0];
        String songName = metaDataArray[1];
        if(artist.indexOf("|") == 0 || artist.lastIndexOf("|") == artist.length() - 1
                || songName.indexOf("|") == 0 ||
                songName.lastIndexOf("|") == songName.length() -1){
            throw new InvalidPlayListException();
        }
        return artist + "||" +songName;
    }
}

/*
* Class Custom Exception, yaitu InvalidPlayListException. Class ini melakukan inheritance
* terhadap kelas Exception dan melakukan override toString
*  untuk menampilkan pesan yang sesuai
* */
class InvalidPlayListException extends Exception{

    @Override
    public String toString() {
        return "Playlist tidak valid!";
    }
}
