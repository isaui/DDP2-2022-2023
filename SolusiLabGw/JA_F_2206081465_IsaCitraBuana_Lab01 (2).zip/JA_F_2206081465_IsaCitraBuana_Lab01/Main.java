//Nama: Isa Citra Buana
//NPM: 2206081465
//Kelas: DDP-2F

import java.text.DecimalFormat;
import java.util.Scanner;
// import kelas yang dibutuhkan dari module yang tersedia

public class Main {
    public static void main(String[] args) { //Method yang dipanggil pertama kali dan berfungsi sebagai tempat eksekusi
        Scanner scanner = new Scanner(System.in);
        //Initialize objek scanner dengan konstruktor yang di passing dengan System.in untuk membaca input user
        System.out.println("Selamat datang di Toko Fotokopi Dek Depe!");
        System.out.println("___________________________________________");
        System.out.print("Masukkan jumlah mahasiswa yang ingin melakukan fotokopi: ");
        int jumlahMahasiswa = scanner.nextInt();
        //Masukkan hasil integer dari input user ke variable jumlahMahasiswa

        int start = 0; // Initialize index untuk while loop
        DecimalFormat decimalFormat = new DecimalFormat("0.00"); // Format dua digit di belaksng koma
        double pendapatanToko = 0; // Initialize pendapatanToko dengan nilai 0

        while (start < jumlahMahasiswa){
            System.out.printf("---------------------DATA MAHASISWA %d----------------------", start + 1);
            System.out.println();
            System.out.print("Nama: ");
            String nama = scanner.next(); //Ambil String
            System.out.print("IPK: ");
            double ipk = scanner.nextDouble(); //Ambil double
            System.out.print("Jumlah lembar: ");
            int jumlahLembar = scanner.nextInt(); //Ambil integer
            System.out.println(nama+ " membayar seharga "+String.format("%.2f", Double.valueOf(decimalFormat.format(setelahDiskon(ipk,jumlahLembar))))+
                    " dengan diskon sebesar "+(int)setelahDiskon(ipk,jumlahLembar,true)+"%");
            pendapatanToko+= setelahDiskon(ipk,jumlahLembar);
            //Tambahkan biaya belanja mahasiswa setelah didiskon ke pendapatan toko
            start++; //Increment
        }
        System.out.println("---------------------RINGKASAN DATA-----------------------");
        System.out.println("Hasil pendapatan yang diperoleh Toko Fotokopi dari "+
                start+" mahasiswa adalah "+ String.format("%.2f",pendapatanToko));

    }


    /*Method overloading, jika dipanggil dengan dua argumen maka akan me-return harga setelah didiskon
    Sementara apabila dipanggil dengan tiga argument
     (argumen ketiga bernilai boolean true) maka akan me-return jumlah diskon*/
    public  static double setelahDiskon(double ipk, int jumlahLembar){
        return  setelahDiskon(ipk, jumlahLembar, false);
    }
    public static double setelahDiskon(double ipk, int jumlahLembar, boolean ambilDiskon){

        int discount = 10;
        if(ipk > 2.5 && ipk <= 3.0){
            discount = 25;
        } else if (ipk > 3.0 && ipk <= 3.5) {
            discount = 35;
        } else if(ipk > 3.5 && ipk <= 4.0){
            discount = 50;
        }
        if( ambilDiskon){
            return  discount;
        }
        return jumlahLembar * 555 * (100-discount)/100d;
    }
}