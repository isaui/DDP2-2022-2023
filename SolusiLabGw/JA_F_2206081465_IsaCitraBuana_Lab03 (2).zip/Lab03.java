//Lab 03 DDP2
//Isa Citra Buana
//2206081465

import java.util.Scanner;
//import kelas yang dibutuhkan, yaitu Scanner di mana dalam hal ini
// objeknya akan digunakan untuk membaca input

public class Lab03 {
    private static String[] arrayMataKuliah;
    //Declare variabel #arrayMataKuliah yang nantinya akan diisi oleh
    // fixed size primitive array of Strings yang menyimpan nama mata kuliah
    private static String[] mahasiswa = new String[5];
    //Buat primitive array of Strings yang menyimpan nama mahasiswa dengan ukuran awal 5
    private static  int [][] nilaiMahasiswa;
    //declare variabel #nilaiMahasiswa yang nantinya akan diisi oleh fixed size
    // primitive array of integer arrays
    private static int countMataKuliah = 0;
    //Buat counter untuk menghitung banyak mata kuliah
    private static  int countSlotNilai = 0;
    //Buat counter untuk jumlah slot nilai, hal ini juga didasarkan pada
    // banyak mata kuliah nantinya
    private static  int countMahasiswa = 0;
    //Buat counter untuk menghitung banyak mahasiswa
    private static Scanner scanner =new Scanner(System.in);
    //objek scanner

    public static void main(String[] args) {
        System.out.println("Selamat datang di BeJayNG!");
        System.out.println("==============Initial Input==============");
        System.out.print("Masukkan jumlah mata kuliah: ");
        int jumlahMatkul = scanner.nextInt();
        arrayMataKuliah = new  String[jumlahMatkul];
        //Buat array of Strings berukuran jumlah mata kuliah
        scanner.useDelimiter("\\n");
        // Delimiter  agar scanner.next dapat membaca 1 baris nama mahasiswa, tidak hanya 1 kata

        //Input nama mata kuliah
        for(int indexMatkul = 0; indexMatkul < jumlahMatkul; indexMatkul++){
            System.out.print("Masukkan nama mata kuliah: ");
            String matkul = scanner.next();
            addLastToArrayMataKuliah(matkul);
        }
        nilaiMahasiswa = new int[5][countSlotNilai];
        //Buat array of integer arrays untuk menyimpan nilai mahasiswa nantinya

        boolean berhenti = false;
        while (!berhenti){ //Tampilkan user interface
            System.out.println("==============Menu==============");
            System.out.println("""
                    [1] Menambah Mahasiswa
                    [2] Menghapus Mahasiswa
                    [3] Mencetak Tabel
                    [4] Mencetak Nilai
                    [0] Keluar                     """);
            System.out.print("Masukkan pilihan: ");
            int pilihan = scanner.nextInt();

            switch (pilihan){
                case  1: // Case menambah mahasiswa
                    System.out.print("Masukkan nama mahasiswa: ");
                    String namaMahasiswa = scanner.next();
                    addMahasiswa(namaMahasiswa);
                    addNilai(namaMahasiswa);
                    System.out.println(
                            String.format("Nilai mahasiswa bernama %s berhasil diinput ke BeJayNG", namaMahasiswa));
                    break;
                case 2: // Case menghapus mahasiswa
                    System.out.println("==============Menghapus Mahasiswa==============");
                    System.out.print("Masukkan nama mahasiswa: ");
                    String namaMahasiswaAkanDihapus = scanner.next();
                    deleteMahasiswa(namaMahasiswaAkanDihapus);
                    break;
                case  3: // Case mencetak tabel
                    System.out.println("==============Mencetak Tabel==============");
                    cetakTabel();
                    break;
                case 4: // Case mencetak nilai mata kuliah tertentu dari mahasiswa tertentu
                    System.out.println("==============Mencetak Nilai==============");
                    System.out.print("Masukkan nama mahasiswa: ");
                    String nama = scanner.next();
                    System.out.print("Masukkan nama mata kuliah: ");
                    String matkul = scanner.next();
                    System.out.println(dapatkanNilai(nama, matkul));
                    break;
                case 0: // Case exit program
                    berhenti = true;
                    System.out.println("Terima kasih telah menggunakan BeJayNG!");
                    break;
                default:
                    // Case di mana command tidak tersedia dalam lab ini
                    System.out.println("Command tidak diketahui. Silahkan coba lagi...");
            }

        }


    }

    // Method untuk mendapatkan nilai mata kuliah tertentu dari mahasiswa tertentu.
    // Method ini mencari indeks mahasiswa terlebih dahulu di array #mahasiswa  dengan linear search.
    // Setelah itu, method ini mencari indeks nama mata kuliah di array #arrayMataKuliah.
    // Jika mata kuliah atau nama mahasiswa yang dicari tidak ada (ditandai
    // dengan #indexMatkul = -1 atau #indexMahasiswa = -1), maka program akan return pesan
    //"Mahasiswa bernama [nama mahasiswa] mungkin tidak ada atau mata kuliah [nama mata kuliah] tidak ada".
    // Jika nama mahasiswa ada dan nama mata kuliah ada maka program akan return pesan
    // "Nilai [nama mahasiswa] di mata kuliah [nama mata kuliah] adalah [nilai mata kuliah]"
    public  static  String dapatkanNilai( String nama, String matkul){
        int indexMahasiswa = -1, indexMatkul = -1;
        for (int index = 0; index < mahasiswa.length; index++){
            if(mahasiswa[index]!= null){
                if (nama.equals(mahasiswa[index])){
                    indexMahasiswa = index;
                }
            }
        }
        for(int index = 0; index < arrayMataKuliah.length; index++){
            if(arrayMataKuliah[index]!= null){
                if(matkul.equals(arrayMataKuliah[index])){
                    indexMatkul = index;
                }
            }
        }
        if (indexMatkul == -1 || indexMahasiswa == -1){
            return String.format(
                            "Mahasiswa bernama %s mungkin tidak ada atau mata kuliah %s tidak ada", nama, matkul);
        }
        return String.format("Nilai %s di mata kuliah %s adalah %d", nama, matkul,
                nilaiMahasiswa[indexMahasiswa][indexMatkul]);
    }

    // Method ini digunakan untuk mencetak tabel. Caranya adalah dengan memanfaatkan StringBuilder #headerBuilder
    // untuk menyimpan nama mahasiswa dan nama nama mata kuliah. Kemudian panggil
    // method #toString dari objek StringBuilder tersebut agar dapat diprint
    // Lalu buat StringBuilder #stringBuilder di setiap iterasi terhadap array #mahasiswa,
    // untuk menyimpan nama mahasiswa dan nilai mata kuliah. Lalu gunakan method #toString
    // objek StringBuilder tersebut agar dapat diprint
    public static void  cetakTabel(){
        StringBuilder headerBuilder = new StringBuilder();
        headerBuilder.append("Nama\t\t\t");
        for(String matkul : arrayMataKuliah){
            headerBuilder.append(String.format("%-12s",matkul));
        }
        System.out.println(headerBuilder.toString());
        for (int index = 0; index < mahasiswa.length; index++){
            if(mahasiswa[index] != null){
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(mahasiswa[index]+"\t\t\t");
                for (int nilai : nilaiMahasiswa[index]){
                    stringBuilder.append(String.format("%-12s", nilai));
                }
                System.out.println(stringBuilder.toString());
            }
        }
    }

    //Method untuk menambahkan nama mahasiswa ke array #mahasiswa.
    // indexingnya memanfaatkan static variabel #countMahasiswa
    // Apabila #countMahasiswa == panjang array #mahasiswa maka buat array baru dengan ukuran 2x lipat,
    // Lalu copy semua elemen ke array baru tersebut
    // Kemudian static variable #mahasiswa menunjuk ke array baru tersebut
    // Tidak lupa untuk increment #countMahasiswa

    public static  void  addMahasiswa(String namaMahasiswa){
        if(countMahasiswa == mahasiswa.length){
            String[] arrayMahasiswaBaru = new  String[countMahasiswa*2];
            int[][] nilaiMahasiswaBaru = new int[countMahasiswa*2][nilaiMahasiswa.length];
            for (int numElement = 0 ; numElement < countMahasiswa; numElement++){
                arrayMahasiswaBaru[numElement] = mahasiswa[numElement];
                nilaiMahasiswaBaru[numElement] = nilaiMahasiswa[numElement];
            }
            mahasiswa = arrayMahasiswaBaru;
            nilaiMahasiswa = nilaiMahasiswaBaru;
        }
        mahasiswa[countMahasiswa++] = namaMahasiswa;
    }
    //Method untuk menambahkan nama mata kuliah ke array #arrayMataKuliah.
    // indexingnya memanfaatkan static variabel #countMataKuliah
    // Apabila #countMataKuliah == panjang array #arrayMataKuliah maka buat array baru dengan ukuran 2x lipat,
    // Lalu copy semua elemen ke array baru tersebut
    // Kemudian static variable #arrayMataKuliah menunjuk ke array baru tersebut
    // Tidak lupa untuk increment #countMataKuliah dan #countSlotNilai
    public static void  addLastToArrayMataKuliah(String mataKuliah ){
        if(countMataKuliah == arrayMataKuliah.length){

            String[] arrayMataKuliahBaru = new String[countMataKuliah*2];
            for (int numElement = 0; numElement < countMataKuliah; numElement++){
                arrayMataKuliahBaru[numElement] = arrayMataKuliah[numElement];
            }
            arrayMataKuliah = arrayMataKuliahBaru;
        }
        arrayMataKuliah[countMataKuliah++] = mataKuliah;
        countSlotNilai++;
    }

    // Method untuk membuat elemen dengan nama mahasiswa tersebut menjadi null dan begitu pula pada array nilainya.
    // Jika #chooseIndex = -1, maka nama mahasiswa tersebut sebelumnya tidak ada. maka tidak ada yang di-null kan
    // maka method ini akan menampilkan pesan "nama mahasiswa tidak ada sebelumnya".
    // Jika nama mahasiswa ada (#chooseIndex != -1) maka null kan nama tersebut dan buat array nilainya menjadi null
    // Kemudian tampilkan pesan "Mahasiswa bernama [nama mahasiswa] telah dihapus dari BeJayNG
    public static void  deleteMahasiswa(String namaMahasiswa){
        int chooseIndex = -1;
        for(int index = 0; index < mahasiswa.length; index++){
            if (mahasiswa[index] != null){
                if (namaMahasiswa.equals(mahasiswa[index])){
                    chooseIndex = index;
                }
            }
        }
        if(chooseIndex == -1){
            System.out.println("nama mahasiswa tidak ada sebelumnya");
            return;
        }
        mahasiswa[chooseIndex] = null;
        nilaiMahasiswa[chooseIndex] = null;
        System.out.println(String.format("Mahasiswa bernama %s telah dihapus dari BeJayNG", namaMahasiswa));
    }

    // Method untuk menambahkan nilai tiap mata kuliah mahasiswa yang baru diinput
    // Cari indeks nama mahasiswa yang sesuai dengan looping terhadap #arrayMahasiswa
    // Setelah itu berikan nilai ke nested array di array #nilaiMahasiswa sembari looping
    public static  void  addNilai(String namaMahasiswa){
        int choosedIndex = 0;
        for(int index = 0; index < mahasiswa.length; index++){
            if(namaMahasiswa.equals(mahasiswa[index])){
                choosedIndex = index;
            }
        }

        for(int index = 0; index < arrayMataKuliah.length; index++){
            System.out.print("Masukkan nilai "+ arrayMataKuliah[index]+": ");
            int nilai = scanner.nextInt();
            nilaiMahasiswa[choosedIndex][index] = nilai;
        }

    }

}