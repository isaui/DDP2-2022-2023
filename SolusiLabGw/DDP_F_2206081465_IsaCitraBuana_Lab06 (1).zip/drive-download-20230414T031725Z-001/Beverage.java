public class Beverage {
    // TODO: Ubah modifier yang tepat untuk atribut pada class ini
    private String name; // variabel String untuk menampung nama objek ini
    private String size; // variabel String untuk menampung jenis size
    private boolean isCold;// variabel boolean untuk cek apakah objek Beverage ini dingin atau tidak
    private int price; // variabel int untuk menyimpan harga objek ini
  
    public Beverage(String name, String size, boolean isCold) {
        //set nama untuk field #name, size untuk field #size, dan nilai true/false untuk field #isCold
      this.name = name;
      this.size = size;
      this.isCold = isCold;
    }

    //getter untuk #price
    public int getPrice() {
        return price;
    }

    //getter untuk #name
    public String getName() {
        return name;
    }

    //getter untuk #size
    public String getSize() {
        return size;
    }

    //setter untuk #price
    public void setPrice(int price) {
        this.price = price;
    }

    // Method sengaja dikosongkan karena akan di-override untuk mengkalkulasi harga
    public void calculatePrice() {
    }

    // method untuk menampilkan representasi objek dalam String
    public String toString() {
      String output = "";
  
      if (isCold) {
        output += "COLD ";
      } else {
        output += "HOT ";
      }
  
      output += this.size + " " + this.name;
      return output;
    }
  }