public class Coffee extends Beverage {

    private boolean hasWhipCream = false;
    //variabel boolean untuk menandai apakah objek Coffee ini sudah diberi topping whip cream atau belum
  
    public Coffee(String nama, String size, boolean isCold) {
        super(nama, size, isCold); // Panggil constructor superclass, yaitu constructor kelas Beverage untuk set field
        // #name, #size, dan #isCold
        calculatePrice(); // Kalkulasi harga
    }



    @Override
    public void calculatePrice() {
        // Set harga untuk objek ini dengan memanggil setter #setPrice yang telah didefinisikan di class Beverage
        // Gunakan ternary operator untuk cek apakah sudah ada topping dan apa jenis sizenya untuk menentukan harga yang tepat
        setPrice((hasWhipCream? 5000 : 0) + (getSize().equalsIgnoreCase("VENTI")? 30000 :
                (getSize().equalsIgnoreCase("GRANDE")? 25000 : 20000)));
    }

    // Ubah field boolean #hasWhipCream menjadi true dan hitung ulang harga objek ini
    public void addWhipCream() {
      // TODO: inisiasi whip cream pada coffee
        hasWhipCream = true;
        calculatePrice();
    }

    // Override #toString untuk menambahkan keterangan topping dan harga
    // method untuk menampilkan representasi objek dalam String
    @Override
    public String toString() {
      String res = super.toString();
      
      if (hasWhipCream) {
        res += " with Whip Cream";
      }
      res += " Rp. " + getPrice() + ",-";
      return res;
    }
  }