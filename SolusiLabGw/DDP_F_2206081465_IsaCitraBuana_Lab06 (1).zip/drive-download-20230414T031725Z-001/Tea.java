public class Tea extends Beverage {

    private boolean hasMilk; // variabel boolean untuk menandai apakah objek Tea ini sudah diberi topping Milk atau belum

    public Tea(String nama, String size, boolean isCold) {

        super(nama, size, isCold);
        // Panggil constructor superclass, yaitu constructor kelas Beverage untuk set field #name, #size, dan #isCold

        calculatePrice(); // Kalkulasi harga
    }

    @Override
    public void calculatePrice() {
        // Set harga untuk objek ini dengan memanggil setter #setPrice yang telah didefinisikan di class Beverage
        // Gunakan ternary operator untuk cek apakah sudah ada topping dan apa jenis sizenya untuk menentukan harga yang tepat
        setPrice((hasMilk? 7000 : 0) + (getSize().equalsIgnoreCase("VENTI")? 25000 :
                getSize().equalsIgnoreCase("GRANDE")? 20000 : 15000 ));
    }

    public void addMilk() {
        // Ubah field boolean #hasMilk menjadi true kemudian hitung ulang harganya dengan memanggil method #calculatePrice
        hasMilk = true;
        calculatePrice();
    }

    // Override #toString untuk menambahkan keterangan topping dan harga
    // method untuk menampilkan representasi objek dalam String
    @Override
    public String toString() {
        String res = super.toString();

        if (hasMilk) {
          res += " with Milk";
        }
    
        res += " Rp. " + this.getPrice() + ",-";

    
        return res;
    }
}