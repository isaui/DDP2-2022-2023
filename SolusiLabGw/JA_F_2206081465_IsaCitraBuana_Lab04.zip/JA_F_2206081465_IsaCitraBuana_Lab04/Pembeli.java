class Pembeli {

    // TODO: Implementasi visibility modifier yang sesuai
    private String nama;
    private long jumlahUang;
    private Pesanan[] listPesanan = new Pesanan[20];
    private final int MAKS_JUMLAH_BARANG = 20;
    private int currentJumlah = 0; // initialize #currentJumlah untuk mencatat jumlah barang saat ini
    private int currentIndex = 0;  // initialize #currentIndex untuk mencatat pointer index array #listPesanan saat ini
    private long currentTotalHargaPesanan = 0L; // Initialize #currentTotalHargaPesanan untuk mencatat
    // total jumlah harga seluruh pesanan yang tersimpan pada #listPesanan saat ini

    // TODO: Implementasi constructor yang sesuai
    public Pembeli(String nama, long jumlahUang){
        this.nama = nama; // set nama pembeli
        this.jumlahUang = jumlahUang; // set jumlah uang pembeli
    }

    /*
     * Method yang akan mengembalikan sebuah String yang merupakan pesan hasil dari
     * query BELI.
     */
    public String tambahPesanan(Barang barang, int jumlah){
        // TODO: Implementasi method tambahPesanan
        if(barang.getStok() < jumlah){
            return  String.format("Tidak bisa memesan %s sebanyak %d buah. Stok barang tidak cukup", barang.getNama(), jumlah);
        }
        else if(currentJumlah + jumlah > MAKS_JUMLAH_BARANG){
            return String.format("Tidak bisa memesan %s sebanyak %d buah. List pesanan %s melebihi kapasitas",
                    barang.getNama(), jumlah, this.nama);
        }
        else if(jumlahUang < barang.getHarga() * jumlah + currentTotalHargaPesanan){
            return  String.format("Tidak bisa memesan %s sebanyak %d\n" +
                    "buah. Uang %s tidak cukup", barang.getNama(),jumlah,this.nama);
        }
        int index = cariIndexPesanan(barang); // temukan indeks yang sesuai untuk pesanan pada array #listPesanan

        // Jika menambah pesanan barang yang sudah pernah dipesan sebelumnya, maka simpan perubahan di objek pesanan yang sama
        if(index!=-1){
            Pesanan temp = new Pesanan(listPesanan[index].getBarang(), listPesanan[index].getJumlahBarang());
            listPesanan[index].setJumlahBarang(listPesanan[index].getJumlahBarang()+jumlah);
            currentTotalHargaPesanan+= listPesanan[index].totalHarga() - temp.totalHarga();
            //catat total harga pesanan sementara

        }else {
            // Apabila memesan pesanan barang yang belum pernah dipesan sebelumnya,
            // alokasikan element pada #currentIndex untuk menyimpan objek pesanan yang baru
            listPesanan[currentIndex] = new Pesanan(barang,jumlah);
            currentTotalHargaPesanan+= listPesanan[currentIndex].totalHarga();
            //catat total harga pesanan sementara

            currentIndex++; // increment
        }
        currentJumlah+=jumlah; //tambahkan jumlah ke #currentJumlah
        barang.setStok(barang.getStok()-jumlah); // kurangi stok barang
        return String.format("%s berhasil memesan %s sebanyak %d buah",this.nama, barang.getNama(), jumlah);
    }

    // Method untuk mencari indeks  untuk pesanan barang yang tepat di array #listPesanan.
    // Mengembalikan integer  untuk indeks yang bersesuaian.
    // Apabila pesanan barang yang dicari tidak ditemukan maka mengembalikan nilai -1 sebagai tanda invalid
    public int cariIndexPesanan(Barang barang){
        int index = 0;
        for(Pesanan pesanan: listPesanan){
            if(pesanan!= null) {
                if (pesanan.getBarang().getNama().equals(barang.getNama())) {
                    return index;
                }
            }
            index++;
        }
        return  -1;
    }
    

    /*
     * Method untuk mengosongkan list pesanan
     */
    // method ini juga me-reset  integer  #currentIndex yang digunakan sebagai
    // pointer indexing pada array #listPesanan
    // method ini juga me-reset integer #currentJumlah yang digunakan sebagai
    // variabel untuk menyimpan jumlah pesanan saat ini
    // method ini juga me-reset long #currentTotalHargaPesanan yang digunakan
    // sebagai variabel untuk menghitung total harga pesanan saat ini
    public void resetPesanan(){

        listPesanan = new Pesanan[20];
        currentJumlah = 0;
        currentTotalHargaPesanan = 0;
        currentIndex = 0;
    }

    // TODO: Tambahkan getter/setter/method lain yang diperlukan


    public long getCurrentTotalHargaPesanan() {
        return currentTotalHargaPesanan;
    }

    public int getCurrentJumlah() {
        return currentJumlah;
    }

    public void setJumlahUang(long jumlahUang) {
        this.jumlahUang = jumlahUang;
    }
    public long getJumlahUang() {
        return jumlahUang;
    }

    public Pesanan[] getListPesanan() {
        return listPesanan;
    }


    public String getNama() {
        return nama;
    }

}
