import java.io.*;
import java.util.StringTokenizer;

public class Diskonpedia {

    private static InputReader in = new InputReader(System.in);
    private static PrintWriter out = new PrintWriter(System.out);
    private static Barang[] listBarang;
    private static Pembeli[] listPembeli;

    /*
     * Method utama program
     */
    public static void main(String[] args) {

        // Inisiasi Barang
        int jumlahBarang = in.nextInt();
        listBarang = new Barang[jumlahBarang];

        for(int i = 0; i < jumlahBarang; i++){
            String namaBarang = in.next();
            long harga = in.nextLong();
            int stok = in.nextInt();
            listBarang[i] = new Barang(harga,namaBarang,stok);

            //TODO: Inisiasi objek barang baru dan masukkan ke listBarang

        }

        // Inisiasi Pembeli
        int jumlahPembeli = in.nextInt();
        listPembeli = new Pembeli[jumlahPembeli];

        for(int i = 0; i < jumlahPembeli; i++){
            String namaPembeli = in.next();
            long jumlahUang = in.nextLong();

            //TODO: Inisiasi objek pembeli baru dan masukkan ke listPembeli
            listPembeli[i] = new Pembeli(namaPembeli, jumlahUang);
        }

        // Jalanin Query
        int jumlahPerintah = in.nextInt();

        for(int i = 0; i < jumlahPerintah; i++){
            String perintah = in.next();
            switch (perintah) {
                case "PESAN" -> {
                    String namaPembeli = in.next();
                    String namaBarang = in.next();
                    int jumlah = in.nextInt();
                    pesan(namaPembeli, namaBarang, jumlah);
                    break;
                }
                case "BAYAR" -> {
                    String namaPembeli = in.next();
                    bayar(namaPembeli);
                    break;
                }
                case "DISKON" -> {
                    String namaPembeli = in.next();
                    diskon(namaPembeli);
                    break;
                }
                case "RESTOCK" -> {
                    String namaBarang = in.next();
                    int jumlah = in.nextInt();
                    restock(namaBarang, jumlah);
                    break;
                }
            }
        }
        out.close();
    }

    /*
     * Method untuk perintah PESAN
     */
    public static void pesan(String namaPembeli, String namaBarang, int jumlah){
        //TODO: Implementasi perintah PESAN
        Pembeli pembeliMauPesan = cariPembeli(namaPembeli);
        Barang barang = cariBarang(namaBarang);
        out.println(pembeliMauPesan.tambahPesanan(barang, jumlah));
    }

    /*
     * Method untuk perintah BAYAR. Asumsi pembeli pasti ada.
     */
    public static void bayar(String namaPembeli){
        // TODO: Implementasi perintah BAYAR
        Pembeli pembeliMauBayar = cariPembeli(namaPembeli);
        // cari objek pembeli yang sesuai namanya  dengan String #namaPembeli
        out.println(String.format("%s berhasil melakukan pembelian barang dan pembayaran!",
                pembeliMauBayar.getNama()));
        out.println("########## Detail Pembayaran ##########");
        Pesanan[] listPesanan = pembeliMauBayar.getListPesanan();
        // Dapatkan list pesanan pembeli tersebut
        long totalHargaHarusDibayar = 0;
        // inisiasi total harga yang harus dibayar mula mula 0
        for(int i = 0; i < listPesanan.length; i++){
            if(listPesanan[i] != null){ // Fokus pada objek pesanan yang bukan null
                Pesanan currentPesanan = listPesanan[i];
                out.println(
                        String.format("%s: %d * %d = %d",
                                currentPesanan.getBarang().getNama(),currentPesanan.getBarang().getHarga(),
                                currentPesanan.getJumlahBarang(),
                                currentPesanan.totalHarga())
                );
                totalHargaHarusDibayar+= currentPesanan.totalHarga();
                // tambahkan ke #totalHargaHarusDibayar
            }
        }
        long totalHargaSetelahDiskon = totalHargaHarusDibayar - hitungDiskon(pembeliMauBayar);
        // dapatkan total harga atau biaya setelah diskon
        out.println("_____________________________________");
        out.println(String.format("Total harga = %d",totalHargaHarusDibayar));
        out.println(String.format("Diskon = %d", hitungDiskon(pembeliMauBayar)));
        out.println("Harga bayar = "+totalHargaSetelahDiskon);
        pembeliMauBayar.setJumlahUang(pembeliMauBayar.getJumlahUang()-totalHargaSetelahDiskon);
        pembeliMauBayar.resetPesanan();
        out.println(String.format("Sisa uang = %d", pembeliMauBayar.getJumlahUang()));
        out.println("#######################################");


    }

    /*
     * Method untuk perintah RESTOCK
     */
    // Restock hanya berlaku jika jumlah restock > 0. Asumsi nama barang pasti valid
    public static void restock(String namaBarang, int jumlah){
        //TODO: Implementasi perintah RESTOCK
        if(jumlah <= 0){
            out.println("Maaf, stok tambahan yang dimasukkan tidak valid");
            return;
        }
        Barang barang = cariBarang(namaBarang);
        barang.setStok(barang.getStok()+jumlah);
        out.println(String.format("Berhasil menambahkan stok barang %s. Sisa stok " +
                "sekarang = %d",barang.getNama(), barang.getStok()));


    }

    /*
     * Method untuk perintah DISKON.
     */
    public static void diskon(String namaPembeli){
        // TODO: Implementasi method ini
        out.println(namaPembeli + " mendapatkan diskon sebesar "+cariPembeli(namaPembeli).getCurrentJumlah()+"%");


    }

    /*
     * Method untuk mencari berapa diskon
     * dalam rupiah yang didapatkan oleh pembeli
     */
    public static long hitungDiskon(Pembeli pembeli){
        //TODO: Implementasi method ini

        return pembeli.getCurrentJumlah() * pembeli.getCurrentTotalHargaPesanan() / 100;
    }

    /*
     * Method untuk mencari Barang berdasarkan nama
     */
    public static Barang cariBarang(String nama){
        for(Barang barang: listBarang){

            if(barang.getNama().equals(nama))
                return barang;
        }
        return null;
    }

    /*
     * Method untuk mencari Pembeli berdasarkan nama
     */
    public static Pembeli cariPembeli(String nama){
        for(Pembeli pembeli: listPembeli){
            if(pembeli.getNama().equals(nama))
                return pembeli;
        }
        return null;
    }

    // taken from https://codeforces.com/submissions/Petr
    // together with PrintWriter, these input-output (IO) is much faster than the usual Scanner(System.in) and System.out
    // please use these classes to avoid your fast algorithm gets Time Limit Exceeded caused by slow input-output (IO)
    static class InputReader {
        public BufferedReader reader;
        public StringTokenizer tokenizer;

        public InputReader(InputStream stream) {
            reader = new BufferedReader(new InputStreamReader(stream), 32768);
            tokenizer = null;
        }

        public String next() {
            while (tokenizer == null || !tokenizer.hasMoreTokens()) {
                try {
                    tokenizer = new StringTokenizer(reader.readLine());
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            return tokenizer.nextToken();
        }

        public int nextInt() {
            return Integer.parseInt(next());
        }

        public long nextLong() {
            return Long.parseLong(next());
        }

        public double nextDouble() {
            return Double.parseDouble(next());
        }
    }
}
