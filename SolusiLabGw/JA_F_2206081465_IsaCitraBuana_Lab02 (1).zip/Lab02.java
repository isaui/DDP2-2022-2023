
/* Nama: Isa Citra Buana
   NPM: 2206081465
   Kelas: DDP-2F
   LAB 03
 */
import java.util.Scanner; // Import kelas Scanner yang digunakan untuk menerima input user

public class Lab02 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in); // Initialization variabel scanner
        int answer; // Declaration variabel answer yang nantinya digunakan untuk menerima input integer
        String namaKupon; // Declaration variabel namaKupon yang nantinya digunakan untuk menerima input String
        String namaKuponCheck; // Declaration variabel namaKuponCheck yang nantinya akan digunakan ketika validasi kupon
        while (true){ // Loop hingga user input 3
            System.out.println("Halo! Apa yang ingin kamu lakukan?");
            System.out.println("[1] Buat kupon");
            System.out.println("[2] Validasi kupon");
            System.out.println("[3] Keluar");
            System.out.print("Pilihan: ");
            answer = scanner.nextInt(); // Get & Store input integer
            if(answer == 1){ // Branch untuk membuat kupon
                System.out.print("Nama kupon: ");
                namaKupon = scanner.next(); // Get & Store input String
                for(int i = 0; i < 2; i++){
                    // Loop untuk String concatenation antara nama kupon dengan String yang ekivalen dengan checksum
                    namaKupon = namaKupon + getCheckSum(createCheckSum(namaKupon)%26);
                }
                System.out.println("Kode kupon adalah: "+namaKupon);
            } else if (answer == 2){ // Branch untuk validasi kupon
                System.out.print("Kupon: ");
                namaKupon = scanner.next(); // Get & Store input String
                namaKuponCheck = namaKupon.substring(0,namaKupon.length()-2); // Ambil nama awal kupon tanpa checksum
                for (int i = 0; i < 2; i++){
                    // Loop untuk String concatenation antara nama kupon dengan String yang ekivalen dengan checksum
                    namaKuponCheck = namaKuponCheck + getCheckSum(createCheckSum(namaKuponCheck)%26);
                }

                if(namaKuponCheck.equals(namaKupon)){
                    //Branch apabila kupon valid
                    System.out.println("Kupon yang diberikan valid");
                }else {
                    //Branch apabila kupon invalid
                    System.out.println("Kupon yang diberikan tidak valid");
                }
            }
            else if(answer == 3){ // Branch untuk exit dari loop
                break;
            }
        }

    }
    public static String getCheckSum(int number){
        //Convert integer ke  value char yang sesuai dengan soal kemudian char tersebut dikonversi ke String
        char equivalentChar = (char) (number+65);
        return String.valueOf(equivalentChar);
    }


    /* Static method rekursif untuk menjumlahkan nilai semua huruf.
     Static method ini memiliki base case ketika length dari String yang dimasukkan
     pada argumen fungsi tersebut sudah bernilai nol.
     */
    public  static  int createCheckSum(String text){
        if(text.length() == 0){
            return  0;
        }
        return (int)((char)text.charAt(0)) - 65 + createCheckSum(text.substring(1));
    }
}
