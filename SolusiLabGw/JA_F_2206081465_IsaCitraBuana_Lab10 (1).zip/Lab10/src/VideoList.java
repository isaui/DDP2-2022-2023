// TODO: Implementasi Class berikut
//  Hal yang perlu diimplementasi:
//  -) Buat class ini dapat menerima object apapun yang berupa Video
//  -) Atribut videoList
//  -) Constructor
//  -) Method insertVide(), deleteVideo(), getVideoList(), getFirst()

import java.util.ArrayDeque;

public class VideoList<T extends Video>{
    private ArrayDeque<T> videoList; // pakai array deque yang merupakan double ended queue
    public VideoList(){
        this.videoList = new ArrayDeque<>();
    }
    public void insertVideo(T newVideo, boolean isFront){
        if(isFront) this.videoList.addFirst(newVideo); // front enqueue
        else this.videoList.addLast(newVideo); // back enqueue
    }

    public ArrayDeque<T> getVideoList() {
        return videoList;
    }
    public T deleteVideo(){
        return videoList.removeFirst(); // dequeue
    }
    public T getFirst(){
        return videoList.getFirst(); // peek
    }

}
